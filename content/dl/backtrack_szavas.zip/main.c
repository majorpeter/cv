#include <stdio.h>
#include <string.h>
#include <conio.h>

//ez a makr� a keresett index� sz� poz�ci�j�t adja meg:
#define SZO(__idx__) (stack+(szohossz+1)*__idx__)

//kapcsol�k:
//#define WRITEALL
#define NORMALIZEHU
//#define PRINTMAXES

char fname[] = "hun.txt";  //hun, eng, deu
char *stack = NULL; //az �sszes sz�t t�rolja, ami es�lyes
unsigned char szohossz = 0;
int szavak = 0;
int *x, *y, *xb, *yb; //szavak indexei; y v�zszintesek, x f�gg�legesek, -b: backup, egy maxim�lis m�ly�gben
int maxstep = -1; //max. m�lys�g
int success = 0; //siker�lt-e m�r (ha nem, akkor a V�g�n hiba�zenet)
int results = 0; //eddig tal�lt darab

unsigned long int realstep=0UL; //bepr�b�lt szavak sz�ma

void load() {
	FILE *f = fopen(fname,"r");
	char buf[80];
	int c_szavak = 0;
	while (fgets(buf, sizeof(buf), f))
		if (strlen(buf) == szohossz+1)
			c_szavak++;
	printf("%d db %d hosszu szot talaltam.\n\n",c_szavak, szohossz);
	stack = (char*)malloc((szohossz+1)*c_szavak);	//nulltermin�ltak
	fseek(f, 0, SEEK_SET);
	while (fgets(buf, sizeof(buf), f))
		if (strlen(buf) == szohossz+1) {
			strncpy(SZO(szavak), buf, szohossz);
			szavak++;
		}
	fclose(f);
}

void normalize(){ //kisbet�s, angol karakteres legyen a sz�t�mb. jobban olvashat� magyar szavak, es�lyesebb tal�latok
	int i;
	for (i = 0; i < (szohossz+1)*szavak; i++) {
		if ('A'<=stack[i] && stack[i] <= 'Z')
			stack[i] = stack[i]-'a'+'A';
			
		else if (stack[i]=='�')
			stack[i] = '�';
		else if (stack[i]=='�')
			stack[i] = '�';
		else if (stack[i]=='�')
			stack[i] = '�';
		else if (stack[i]=='�')
			stack[i] = '�';
		else if (stack[i]=='�')
			stack[i] = '�';
		else if (stack[i]=='�')
			stack[i] = '�';
		else if (stack[i]=='�')
			stack[i] = '�';
		else if (stack[i]=='�')
			stack[i] = '�';
		else if (stack[i]=='�')
			stack[i] = '�';
		
		#ifdef NORMALIZEHU	
		if (stack[i]=='�')
			stack[i] = 'a';
		else if (stack[i]=='�')
			stack[i] = 'e';
		else if (stack[i]=='�')
			stack[i] = 'i';
		else if (stack[i]=='�')
			stack[i] = 'o';
		else if (stack[i]=='�')
			stack[i] = 'u';
		else if (stack[i]=='�')
			stack[i] = 'o';
		else if (stack[i]=='�')
			stack[i] = 'o';
		else if (stack[i]=='�')
			stack[i] = 'u';
		else if (stack[i]=='�')
			stack[i] = 'u';
		#endif
	}
}

char yesno(char *q) { //eld�ntend� k�rd�s fv.
	char res=-1;
	printf("%s (i/n)\n",q);
	while (res==-1) {
		int c = getchar();
		if (c=='i')
			res=1;
		else if (c=='n')
			res=0;
	}
	return res;
}

void put_in_canvas_x(char *c, char *szo, int x) {
	int y;
	for (y = 0; y < szohossz; y++)
		c[y*szohossz+x]=szo[y];
}

void put_in_canvas_y(char *c, char *szo, int y) {
	strncpy(c+y*szohossz, szo, szohossz);
}

void print_canvas(char *c) {
	int i;
	printf("\n");
	for (i=0; i<szohossz*szohossz; i++) {
		if (!(i%szohossz))
			printf("\n  ");
		printf("%c",c[i]);
	}
	printf("\n\n");
}

void print_max(int *x, int *y) { //tal�lati t�mb ki�r�sa
	int i;
	char *canvas = (char *)malloc(szohossz*szohossz);
	
	printf("Osszesen %d teszt tortent.",realstep);
	for (i = 0; i < szohossz*szohossz; i++)
 		canvas[i]=' ';
	for (i = 0; i < (maxstep/2)+(maxstep%2); i++) {
		#ifdef WRITEALL
		printf(" y[%d]: %s\n",i,SZO(y[i]));
		#endif
		put_in_canvas_y(canvas,SZO(y[i]),i);
	}
	for (i = 0; i < (maxstep/2); i++) {
		#ifdef WRITEALL
		printf(" x[%d]: %s\n",i,SZO(x[i]));
		#endif
		put_in_canvas_x(canvas,SZO(x[i]),i);
	}
	print_canvas(canvas);
	free(canvas);
}

char fits(int step, char *szo) {
	int i;
	for (i = 0; i < (step / 2)+(step%2); i++) //p�ros l�p�sek (0.,2...) v�zszintes sz�t defini�lnak, p�ratlanok (0.,1...) a v�zszintesekhez igazodnak
		if (SZO(((step%2) ? y : x )[i])[step/2] != szo[i])
			return 0;

	return 1;
}

char find(int step) {
	int i;
	
	if (maxstep < step) { //legm�lyebb friss�t�se �s ki�r�sa ha sz�ks�ges
		maxstep = step;
		#ifdef PRINTMAXES
		memcpy(xb,x,sizeof(int)*szohossz);
		memcpy(yb,y,sizeof(int)*szohossz);
		printf("\n Maximalis melyseg: %dx rekurzio;  ", step);
		if (maxstep > 2)
			print_max(x,y);
		#endif
	}
	
	if (step == szohossz*2) { //ennyi rekurzi� m�r a megold�st adja ki
		printf("\n-Talaltam jo lefedest [%d]:\n", ++results);
		success=1;
		print_max(x,y);
		if (!yesno("Keressek mas lefedest is?"))
			return 1;
		else
			return 0;
	}
		
	for (i = 0; i < szavak; i++) {
		realstep++;
		if (fits(step, SZO(i))) { //az �sszes sz�t bepr�b�ljuk a jelenlegi t�mbbe, ha van j�, azzal �jrah�vjuk a f�ggv�nyt
			((step%2) ? x : y )[step/2]=i;
			if (find(step+1)) //m�ghozz� a k�vetkez� l�p�sbe
				return 1;
		}
	}
	
	return 0;
}

main(){
	printf("Kerem a szohosszt!\n");
	scanf("%d",&szohossz);
	load();
	normalize();
	
	x=(int*)malloc(sizeof(int)*szohossz);
	y=(int*)malloc(sizeof(int)*szohossz);
	xb=(int*)malloc(sizeof(int)*szohossz);
	yb=(int*)malloc(sizeof(int)*szohossz);
	
	if (!find(0)) {
		if (!success) {
			#ifndef PRINTMAXES
			print_max(xb,yb);
			#endif
			printf("Nem talalhato ilyen szavakkal lefedes\n");
		}
	}
	
	free(x);
	free(y);
	free(xb);
	free(yb);
	free(stack);
}

/* x  y
0: 0, 0, vizsz
1: 0, 0, fugg,
2: 1, 1, vizsz,
3: 1, 1, fugg,
4: 2, 2, vizsz,
5: 2, 2, fugg -> v�ge, 2n-1 l�p�ssel j�, k�vetkez� rekurzi� �rt�keli ki

	x0 x1 x2 x3
y0  a  b  b  a
y1  b  e  a  d  
y2  b  a  b  a
y3  a  d  a  g

l�p�sek:
step:  0  1  2  3  4  5 ...
val : y0 x0 y1 x1 y2 x2 <- (step/2, [step%2 ? x : y]) ;)
*/

