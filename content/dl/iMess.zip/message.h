enum {IM_KILL_CONNECTION, IM_SETNAME, IM_TEXT_MESSAGE, IM_TEXT_DATA,
	IM_SETCOLOR, IM_SETBGCOL, IM_SENDFILE, IM_SENDFILE_NAME,

	ENDOF_IM};

typedef struct _xmess{
	unsigned int msg;
	unsigned long int param; //4 byte
	struct _xmess * next;
}Msg;

Msg *getMsg();
void putMsg(Msg *msg);
Msg *createMsg(unsigned int _msg, unsigned long int _param);
void pushMsg(unsigned int msg, unsigned long int param, char *instance);
unsigned int text2packetLength(char *txt);
void pushTextData(char *txt, char *instance);
void flushMsgStack();


