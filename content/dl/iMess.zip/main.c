#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#include "main.h"
#include "message.h"
#include "parser.h"

Msg *msg_stack = NULL;
HANDLE hCon;

int main()
{
    hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    setColor(0xc);
    printf("iMess Peldaprogram (c) Major Peter 2011.nov\n-------------\n");
    setColor(0xf);
    createParser();
    parserLoop();
    destroyParser();
    return 0;
}

void setColor(unsigned char col) {
    SetConsoleTextAttribute(hCon, col);
}
