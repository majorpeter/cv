#include <stdio.h>
#include <string.h>
#include <windows.h>

#include "parser.h"
#include "message.h"

void *control[ENDOF_IM];
ParserState pState = StateNeutral;
void *txtControl[StateNeutral];
int packetsLeft = 0;

char instance[] = "a.txt";
char contact[] = "b.txt";
char connected = 0;

char *partner = 0;
char partnercolor=0x0f;

void initControl() {
	control[IM_KILL_CONNECTION] = imKillConnection;
	control[IM_SETNAME] = imSetName;
	control[IM_TEXT_MESSAGE] = imTextMessage;
	control[IM_TEXT_DATA] = imParseText;
	control[IM_SETCOLOR] = imSetCol;
	control[IM_SETBGCOL] = imSetBgCol;
	control[IM_SENDFILE] = imSendFile;
	control[IM_SENDFILE_NAME] = imSendFile_Name;

	txtControl[StateSetName] = parseText_Name;
	txtControl[StateTextMsg] = parseText_Message;
	txtControl[StateFName] = parseText_SendFName;
}

void setInstance() {
    FILE *i;
    if (i=fopen(instance, "r")) {
        instance[0]='b';
        contact[0]='a';
        fclose(i);
        i = fopen(instance, "w");
        fclose(i);
    }
    else {
        i = fopen(instance, "w");
        fclose(i);
    }
    printf("Ez a program \"%c\" peldanya.\n",instance[0]);
}

void createParser() {
    setInstance();
	initControl();
}

void destroyParser() {
    if (partner)
        free(partner);

    remove(instance);
}

char getMessage() {
    FILE *f;
    if (!(f = fopen(contact, "r"))) {
        if (connected) {
            printf("Kapcsolat lezarult!\n");
            return 0;
        }
    }
    else {
        Msg *msg;

        if (!connected) {
            connected = 1;
            printf("Kapcsolat letrejott.\n");
        }
        fseek(f, 0L, SEEK_END);
        if (ftell(f)) {
            fseek(f, 0L, SEEK_SET);
            msg = malloc(sizeof(Msg));
            while (fread(msg, 1, sizeof(unsigned int) + sizeof(unsigned long int), f)) {
                msg->next = 0;
                putMsg(msg);
                msg = malloc(sizeof(Msg));
            }
            free(msg);
        }
        fclose(f);
        remove(contact);
        if (f = fopen(contact, "w"))
            fclose(f);
    }
    return 1;
}

void parserLoop() {
    int i;
    char buf[128];
    printf("Az alabbi billentyuk megnyomasa utan kuldheto uzenet/csomag.\n"
           "    (Esc) explicit kilepes (kapcsolat nincs lezarva)\n"
           "    (0) kapcsolat lezarasa\n"
           "    (1) sajat allomasnev megadasa\n"
           "    (2) szoveges uzenet kuldese a partnernek\n"
           "    (3) fajl kuldese (csak demonstracio)\n"
           "    (4) szin valtasa: ");
    for (i = 0; i <= 0xF; i++) {
        setColor(i);
        printf("%x ", i);
    }
    printf("\n"
           "    (5) Hatterszin valtasa (ugyanugy)\n"
           "----------\n");

    if (instance[0]=='a')
        printf("Varakozas masik felre.\n");

    char waiter = 0;
    while (1) {
        switch(waiter = (waiter+1)%4) {
        case 0: printf("-\r"); break;
        case 1: printf("/\r"); break;
        case 2: printf("|\r"); break;
        case 3: printf("\\\r"); break;
        }

        if (getMessage()) {
            parseStack();
        }
        else
            return;

        if (kbhit()) {
            char c = getch();
            if (c == Key_Esc)
                return;
            else if (c == '1') {
                printf(" (1) - Uj nev: ");
                gets(buf);
                pushMsg(IM_SETNAME, text2packetLength(buf), instance);
                pushTextData(buf, instance);
            }
            else if (c == '2') {
                printf(" \nSajat uzenet: \n");
                gets(buf);
                pushMsg(IM_TEXT_MESSAGE, text2packetLength(buf), instance);
                pushTextData(buf, instance);
            }
            else if (c == '3') {
                //kellene f�jlablak, kiv�laszt�s, m�ret megn�z�se stb; ez�rt ez csak demonstr�ci�.
                char fn[] = "kuldott_fajl.txt";
                unsigned int fsize = 308;
                pushMsg(IM_SENDFILE, fsize, instance);
                pushMsg(IM_SENDFILE_NAME, text2packetLength(fn), instance);
                pushTextData(fn, instance);
                //itt j�nne a f�jl tartalma csomagonk�nt.
            }
            else if (c == '4') {
                printf("Uj szin?\n");
                char b[] = "0x______";
                char c;
                gets(b+2);
                sscanf(b,"%x",&c);
                pushMsg(IM_SETCOLOR, c, instance);
            }
            else if (c == '5') {
                printf("Uj hatterszin?\n");
                char b[] = "0x______";
                char c;
                gets(b+2);
                sscanf(b,"%x",&c);
                pushMsg(IM_SETBGCOL, c, instance);
            }
            else if (c == '0') {
                pushMsg(IM_KILL_CONNECTION, 0, instance);
                printf(" (0): kapcsolat megszakitva\n");
            }
        }

        Sleep(600);
    }
}

void parseStack() {
	Msg *msg;
	while (msg = getMsg()) {
		((void (*)(unsigned long int))(control[msg->msg]))(msg->param);
		free(msg);
	}
}

void imParseText(unsigned long int param) {
	char b[5] = {0,0,0,0,0};
	strncpy(b,(char*)&param,4);

    ((void (*)(char *))(txtControl[pState]))(b);
}

void parseText_Name(char *txt) {
    if (!--packetsLeft)
        pState = StateNeutral;

    strcat(partner, txt);
    if (pState == StateNeutral)
        printf("Partner neve valtozott: %s\n", partner);
}

void parseText_Message(char *txt) {
    if (!--packetsLeft)
        pState = StateNeutral;

    printf(txt);
    if (pState == StateNeutral) {
        printf("\n");
        setColor(0xf);
    }
}

void parseText_SendFName(char *txt) {
    if (!--packetsLeft)
        pState = StateNeutral;

    printf(txt);
    if (pState == StateNeutral) {
        printf("\n");
        setColor(0xf);
    }
}

void imKillConnection(unsigned long int param) {
	printf("A kapcsolatot a masik fel megszakitotta.\n");
}

void imSetName(unsigned long int param) {
	packetsLeft = param;
	pState = StateSetName;
	if (partner)
        free(partner);

    partner = calloc(param*4+1, 1);
}

void imTextMessage(unsigned long int param) {
    packetsLeft = param;
    pState = StateTextMsg;
    printf("\r \n%s uzenete:\n  ", partner);
    setColor(partnercolor);
}

void imSetCol(unsigned long int param) {
    partnercolor = (partnercolor / 0x10) * 0x10 + param;
    printf("A partner uj szine ");
    setColor(partnercolor);
    printf("ez.\n");
    setColor(0x0f);
}

void imSetBgCol(unsigned long int param) {
    partnercolor = param * 0x10 + partnercolor % 0x10;
    printf("A partner uj hatterszine ");
    setColor(partnercolor);
    printf("ez.\n");
    setColor(0x0f);
}

void imSendFile(unsigned long int param) {
    printf("Bejovo fajl, merete: %u\n", param);
}

void imSendFile_Name(unsigned long int param) {
    packetsLeft = param;
    pState = StateFName;
    printf("Fajl neve: ");
}
