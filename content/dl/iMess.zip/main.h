void setColor(unsigned char col);
