typedef enum {StateSetName, StateTextMsg, StateFName, StateNeutral} ParserState;
 #define Key_Esc 27

void createParser();
void destroyParser();
char getMessage();
void parserLoop();
void parseStack();
//void parseText(unsigned long int param);

//textparser
void parseText_Name(char *txt);
void parseText_Message(char *txt);
void parseText_SendFName(char *txt);

//control func
void imKillConnection(unsigned long int param);
void imSetName(unsigned long int param);
void imTextMessage(unsigned long int param);
void imSetCol(unsigned long int param);
void imSetBgCol(unsigned long int param);
void imParseText(unsigned long int param);
void imSendFile(unsigned long int param);
void imSendFile_Name(unsigned long int param);
