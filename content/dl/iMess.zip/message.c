#include <stdio.h>
#include <string.h>

#include "message.h"

extern Msg *msg_stack;

Msg *getMsg() {
	Msg *result;
	result = msg_stack;
	if (msg_stack) {
		msg_stack = msg_stack->next;
	}
	return result;
}

void putMsg(Msg *msg) {
	if (msg_stack) {
		Msg *m = msg_stack;
		while (m->next)
			m = m->next;
		m->next = msg;
	}
	else
		msg_stack=msg;
}

Msg *createMsg(unsigned int _msg, unsigned long int _param) {
	Msg *msg = (Msg*)malloc(sizeof(Msg));
	msg->msg = _msg;
	msg->param = _param;
	msg->next = 0;
	return msg;
}

void pushMsg(unsigned int msg, unsigned long int param, char *instance) {
    extern char connected;

    if (connected) {
        FILE *f;
        if (f = fopen(instance, "a")) { //append
            fwrite(&msg, sizeof(unsigned int), 1, f);
            fwrite(&param, sizeof(unsigned long int), 1, f);
            fclose(f);
        }
        else printf("Nem sikerult kommunikalni.\n");
    }
}

unsigned int text2packetLength(char *txt) {
    unsigned int l = strlen(txt);
    l = (l/4) + ((l % 4) ? 1 : 0);
    return l;
}

void pushTextData(char *txt, char *instance) {
	char b[4]; // = unsigned long int.
	char pos = 0;
	while (*txt) {
		b[pos]=*txt;
		pos++;

		if (pos==4) {
			//putMsg(createMsg(IM_TEXT_DATA, *(unsigned long int*)b));
			pushMsg(IM_TEXT_DATA, *(unsigned long int*)b, instance);
			pos = 0;
		}
		txt++;
	}

	if (pos) {
			while (pos < 4) {
				b[pos] = 0;
				pos++;
			}
			//putMsg(createMsg(IM_TEXT_DATA, (unsigned long int)*b));
			pushMsg(IM_TEXT_DATA, *(unsigned long int*)b, instance);
		}
}

void flushMsgStack() {
	Msg *m;
	while (m = getMsg()) {
		free(m);
	}
}
